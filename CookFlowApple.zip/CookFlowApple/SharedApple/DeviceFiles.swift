import Foundation

enum DeviceFiles {
    static func url(_ name: String) throws -> URL {
        let root = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask,
            appropriateFor: nil, create: true).appendingPathComponent("CookFlow", isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        return root.appendingPathComponent(name)
    }

    static func read<T: Decodable>(_ type: T.Type, name: String) -> T? {
        guard let path = try? url(name), let data = try? Data(contentsOf: path) else { return nil }
        return try? JSONDecoder().decode(type, from: data)
    }

    static func write<T: Encodable>(_ value: T, name: String) throws {
        try CookFlowWire.encode(value).write(to: url(name), options: .atomic)
    }

    static func seed() -> CookFlowState {
        if let path = Bundle.main.url(forResource: "seed", withExtension: "json"),
           let data = try? Data(contentsOf: path),
           let state = try? JSONDecoder().decode(CookFlowState.self, from: data),
           (try? state.validate()) != nil { return state }
        return CookFlowState(recipe: CookingRecipe(title: "My cooking checklist", sections: []),
            shopping: ShoppingList(version: 1, collapsed: false, lastStore: "", stores: []))
    }

    static func readBackup(at url: URL) throws -> CookFlowState {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
        guard size <= 5 * 1_024 * 1_024 else {
            throw DocumentError.invalid("Choose a CookFlow backup smaller than 5 MB.")
        }
        return try CookFlowBackup.read(Data(contentsOf: url))
    }
}
