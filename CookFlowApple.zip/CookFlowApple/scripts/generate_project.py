#!/usr/bin/env python3
"""Generate the dependency-free Xcode project and property lists deterministically."""
from pathlib import Path
import hashlib
import json
import plistlib
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
objects = {}

def uid(name):
    return hashlib.sha256(name.encode()).hexdigest()[:24].upper()

def obj(label, isa, **fields):
    key = uid(label)
    objects[key] = {"isa": isa, **fields}
    return key

def write_plist(path, value):
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(plistlib.dumps(value, sort_keys=False))

base_info = {
    "CFBundleDevelopmentRegion": "$(DEVELOPMENT_LANGUAGE)",
    "CFBundleDisplayName": "CookFlow",
    "CFBundleExecutable": "$(EXECUTABLE_NAME)",
    "CFBundleIdentifier": "$(PRODUCT_BUNDLE_IDENTIFIER)",
    "CFBundleInfoDictionaryVersion": "6.0",
    "CFBundleName": "$(PRODUCT_NAME)",
    "CFBundlePackageType": "APPL",
    "CFBundleShortVersionString": "1.1",
    "CFBundleVersion": "2",
}
phone_info = dict(base_info, LSRequiresIPhoneOS=True, UILaunchScreen={},
    UIApplicationSupportsIndirectInputEvents=True,
    UISupportedInterfaceOrientations=["UIInterfaceOrientationPortrait", "UIInterfaceOrientationLandscapeLeft", "UIInterfaceOrientationLandscapeRight"],
    LSSupportsOpeningDocumentsInPlace=True,
    CFBundleDocumentTypes=[{"CFBundleTypeName": "CookFlow backup", "CFBundleTypeRole": "Editor",
        "LSHandlerRank": "Owner", "LSItemContentTypes": ["com.joelreimer.cookflow.backup"]}],
    UTExportedTypeDeclarations=[{"UTTypeIdentifier": "com.joelreimer.cookflow.backup",
        "UTTypeConformsTo": ["public.json"], "UTTypeDescription": "CookFlow backup",
        "UTTypeTagSpecification": {"public.filename-extension": ["cookflow"], "public.mime-type": "application/json"}}])
watch_info = dict(base_info, WKApplication=True, WKCompanionAppBundleIdentifier="$(COOKFLOW_BASE_BUNDLE_ID)",
    WKRunsIndependentlyOfCompanionApp=False, WKWatchOnly=False)
write_plist("iPhone/Info.plist", phone_info)
write_plist("Watch/Info.plist", watch_info)

shared = ["Core/Sources/CookFlowCore/Models.swift", "Core/Sources/CookFlowCore/SyncEngine.swift", "SharedApple/DeviceFiles.swift"]
phone_sources = ["iPhone/CookFlowPhoneApp.swift", "iPhone/PhoneStore.swift", "iPhone/CookFlowWebView.swift"]
watch_sources = ["Watch/CookFlowWatchApp.swift", "Watch/WatchStore.swift"]
all_paths = shared + phone_sources + watch_sources + ["iPhone/Resources/index.html", "iPhone/Resources/seed.json", "Watch/Resources/seed.json", "iPhone/Assets.xcassets", "Watch/Assets.xcassets", "Config/Signing.xcconfig", "iPhone/Info.plist", "Watch/Info.plist", "README.md"]
refs = {}
for path in all_paths:
    file_type = "sourcecode.swift" if path.endswith(".swift") else "text.plist.xml" if path.endswith(".plist") else "text.xcconfig" if path.endswith(".xcconfig") else "folder.assetcatalog" if path.endswith(".xcassets") else "text.html" if path.endswith(".html") else "text.json" if path.endswith(".json") else "net.daringfireball.markdown"
    refs[path] = obj("file:" + path, "PBXFileReference", lastKnownFileType=file_type, name=Path(path).name, path=path, sourceTree="SOURCE_ROOT")

phone_product = obj("product:phone", "PBXFileReference", explicitFileType="wrapper.application", includeInIndex=0, path="CookFlow.app", sourceTree="BUILT_PRODUCTS_DIR")
watch_product = obj("product:watch", "PBXFileReference", explicitFileType="wrapper.application", includeInIndex=0, path="CookFlowWatch.app", sourceTree="BUILT_PRODUCTS_DIR")
products = obj("products", "PBXGroup", children=[phone_product, watch_product], name="Products", sourceTree="<group>")
groups = []
for name, paths in [("Shared", shared), ("iPhone", phone_sources + [p for p in all_paths if p.startswith("iPhone/") and p not in phone_sources]), ("Watch", watch_sources + [p for p in all_paths if p.startswith("Watch/") and p not in watch_sources]), ("Configuration", ["Config/Signing.xcconfig", "README.md"])]:
    groups.append(obj("group:"+name, "PBXGroup", children=[refs[p] for p in paths], name=name, sourceTree="<group>"))
root_group = obj("root-group", "PBXGroup", children=groups+[products], sourceTree="<group>")

def phase(target, kind, paths):
    files = [obj("build:"+target+":"+p, "PBXBuildFile", fileRef=refs[p]) for p in paths]
    return obj("phase:"+target+":"+kind, "PBX"+kind+"BuildPhase", buildActionMask=2147483647, files=files, runOnlyForDeploymentPostprocessing=0)

common = {"CLANG_ENABLE_MODULES": "YES", "SWIFT_VERSION": "5.0", "SWIFT_STRICT_CONCURRENCY": "minimal",
    "IPHONEOS_DEPLOYMENT_TARGET": "17.0", "WATCHOS_DEPLOYMENT_TARGET": "10.0",
    "ENABLE_USER_SCRIPT_SANDBOXING": "YES", "DEVELOPMENT_LANGUAGE": "en", "ALWAYS_SEARCH_USER_PATHS": "NO"}
def configs(name, extra):
    configs = []
    for build in ["Debug", "Release"]:
        settings = {**common, **extra, "SWIFT_OPTIMIZATION_LEVEL": "-Onone" if build == "Debug" else "-O",
            "DEBUG_INFORMATION_FORMAT": "dwarf" if build == "Debug" else "dwarf-with-dsym",
            "SWIFT_ACTIVE_COMPILATION_CONDITIONS": "DEBUG $(inherited)" if build == "Debug" else "$(inherited)"}
        configs.append(obj("config:"+name+":"+build, "XCBuildConfiguration", baseConfigurationReference=refs["Config/Signing.xcconfig"], buildSettings=settings, name=build))
    return obj("configs:"+name, "XCConfigurationList", buildConfigurations=configs, defaultConfigurationIsVisible=0, defaultConfigurationName="Release")

phone_config = configs("phone", {"SDKROOT": "iphoneos", "SUPPORTED_PLATFORMS": "iphoneos iphonesimulator", "TARGETED_DEVICE_FAMILY": "1",
    "PRODUCT_BUNDLE_IDENTIFIER": "$(COOKFLOW_BASE_BUNDLE_ID)", "PRODUCT_NAME": "CookFlow", "INFOPLIST_FILE": "iPhone/Info.plist",
    "GENERATE_INFOPLIST_FILE": "NO", "ASSETCATALOG_COMPILER_APPICON_NAME": "AppIcon", "ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME": "AccentColor",
    "LD_RUNPATH_SEARCH_PATHS": "$(inherited) @executable_path/Frameworks", "SUPPORTS_MACCATALYST": "NO"})
watch_config = configs("watch", {"SDKROOT": "watchos", "SUPPORTED_PLATFORMS": "watchos watchsimulator", "TARGETED_DEVICE_FAMILY": "4",
    "PRODUCT_BUNDLE_IDENTIFIER": "$(COOKFLOW_BASE_BUNDLE_ID).watchapp", "PRODUCT_NAME": "CookFlowWatch", "INFOPLIST_FILE": "Watch/Info.plist",
    "GENERATE_INFOPLIST_FILE": "NO", "ASSETCATALOG_COMPILER_APPICON_NAME": "AppIcon", "ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME": "AccentColor",
    "LD_RUNPATH_SEARCH_PATHS": "$(inherited) @executable_path/Frameworks", "SKIP_INSTALL": "YES"})
watch_target = obj("target:watch", "PBXNativeTarget", buildConfigurationList=watch_config,
    buildPhases=[phase("watch", "Sources", shared+watch_sources), phase("watch", "Frameworks", []), phase("watch", "Resources", ["Watch/Resources/seed.json", "Watch/Assets.xcassets"])],
    buildRules=[], dependencies=[], name="CookFlowWatch", productName="CookFlowWatch", productReference=watch_product, productType="com.apple.product-type.application")
proxy = obj("watch-proxy", "PBXContainerItemProxy", containerPortal=uid("project"), proxyType=1, remoteGlobalIDString=watch_target, remoteInfo="CookFlowWatch")
dependency = obj("watch-dependency", "PBXTargetDependency", target=watch_target, targetProxy=proxy)
embed_file = obj("embed-watch-file", "PBXBuildFile", fileRef=watch_product, settings={"ATTRIBUTES": ["RemoveHeadersOnCopy"]})
embed = obj("embed-watch", "PBXCopyFilesBuildPhase", buildActionMask=2147483647, dstPath="$(CONTENTS_FOLDER_PATH)/Watch", dstSubfolderSpec=16,
    files=[embed_file], name="Embed Watch Content", runOnlyForDeploymentPostprocessing=0)
phone_target = obj("target:phone", "PBXNativeTarget", buildConfigurationList=phone_config,
    buildPhases=[phase("phone", "Sources", shared+phone_sources), phase("phone", "Frameworks", []), phase("phone", "Resources", ["iPhone/Resources/index.html", "iPhone/Resources/seed.json", "iPhone/Assets.xcassets"]), embed],
    buildRules=[], dependencies=[dependency], name="CookFlow", productName="CookFlow", productReference=phone_product, productType="com.apple.product-type.application")
project = obj("project", "PBXProject", attributes={"BuildIndependentTargetsInParallel": "YES", "LastUpgradeCheck": "1600", "TargetAttributes": {
    phone_target: {"CreatedOnToolsVersion": "16.0", "ProvisioningStyle": "Automatic"}, watch_target: {"CreatedOnToolsVersion": "16.0", "ProvisioningStyle": "Automatic"}}},
    buildConfigurationList=configs("project", {}), compatibilityVersion="Xcode 14.0", developmentRegion="en", hasScannedForEncodings=0,
    knownRegions=["en", "Base"], mainGroup=root_group, productRefGroup=products, projectDirPath="", projectRoot="", targets=[phone_target,watch_target])

def serialize(value, depth=0):
    tab = "\t"*depth
    if isinstance(value, dict):
        return "{\n"+"".join(tab+"\t"+json.dumps(str(k))+" = "+serialize(v,depth+1)+";\n" for k,v in value.items())+tab+"}"
    if isinstance(value, list):
        return "(\n"+"".join(tab+"\t"+serialize(v,depth+1)+",\n" for v in value)+tab+")"
    if isinstance(value, int): return str(value)
    return json.dumps(str(value), ensure_ascii=False)

project_dir = ROOT/"CookFlowApple.xcodeproj"
project_dir.mkdir(exist_ok=True)
(project_dir/"project.pbxproj").write_text("// !$*UTF8*$!\n"+serialize({"archiveVersion":1,"classes":{},"objectVersion":56,"objects":objects,"rootObject":project})+"\n")
for name,target,product in [("CookFlow",phone_target,"CookFlow.app"),("CookFlowWatch",watch_target,"CookFlowWatch.app")]:
    scheme = ET.Element("Scheme", {"LastUpgradeVersion":"1600","version":"1.3"})
    action = ET.SubElement(scheme,"BuildAction",{"parallelizeBuildables":"YES","buildImplicitDependencies":"YES"})
    entries = ET.SubElement(action,"BuildActionEntries")
    entry = ET.SubElement(entries,"BuildActionEntry",{"buildForTesting":"YES","buildForRunning":"YES","buildForProfiling":"YES","buildForArchiving":"YES","buildForAnalyzing":"YES"})
    attributes={"BuildableIdentifier":"primary","BlueprintIdentifier":target,"BuildableName":product,"BlueprintName":name,"ReferencedContainer":"container:CookFlowApple.xcodeproj"}
    ET.SubElement(entry,"BuildableReference",attributes)
    test = ET.SubElement(scheme,"TestAction",{"buildConfiguration":"Debug","selectedDebuggerIdentifier":"Xcode.DebuggerFoundation.Debugger.LLDB","selectedLauncherIdentifier":"Xcode.IDEFoundation.Launcher.LLDB","shouldUseLaunchSchemeArgsEnv":"YES"})
    ET.SubElement(test,"Testables")
    launch = ET.SubElement(scheme,"LaunchAction",{"buildConfiguration":"Debug","selectedDebuggerIdentifier":"Xcode.DebuggerFoundation.Debugger.LLDB","selectedLauncherIdentifier":"Xcode.IDEFoundation.Launcher.LLDB","launchStyle":"0","useCustomWorkingDirectory":"NO","ignoresPersistentStateOnLaunch":"NO","debugDocumentVersioning":"YES","debugServiceExtension":"internal","allowLocationSimulation":"YES"})
    runnable=ET.SubElement(launch,"BuildableProductRunnable",{"runnableDebuggingMode":"0"});ET.SubElement(runnable,"BuildableReference",attributes)
    profile=ET.SubElement(scheme,"ProfileAction",{"buildConfiguration":"Release","shouldUseLaunchSchemeArgsEnv":"YES","savedToolIdentifier":"","useCustomWorkingDirectory":"NO","debugDocumentVersioning":"YES"})
    ET.SubElement(ET.SubElement(profile,"BuildableProductRunnable",{"runnableDebuggingMode":"0"}),"BuildableReference",attributes)
    ET.SubElement(scheme,"AnalyzeAction",{"buildConfiguration":"Debug"});ET.SubElement(scheme,"ArchiveAction",{"buildConfiguration":"Release","revealArchiveInOrganizer":"YES"})
    path=project_dir/"xcshareddata/xcschemes"/(name+".xcscheme");path.parent.mkdir(parents=True,exist_ok=True)
    ET.indent(scheme);ET.ElementTree(scheme).write(path,encoding="utf-8",xml_declaration=True)
workspace=project_dir/"project.xcworkspace";workspace.mkdir(exist_ok=True)
(workspace/"contents.xcworkspacedata").write_text('<?xml version="1.0" encoding="UTF-8"?><Workspace version="1.0"><FileRef location="self:"></FileRef></Workspace>\n')
print("Generated Xcode project with",len(objects),"objects and 2 app targets.")
