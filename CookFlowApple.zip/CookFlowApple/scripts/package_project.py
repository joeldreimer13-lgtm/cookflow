#!/usr/bin/env python3
from pathlib import Path
import zipfile

root=Path(__file__).resolve().parents[1]
destination=Path('/workspace/scratch/b3f533e47cd0/apple-delivery/CookFlowApple.zip')
destination.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(root.rglob('*')):
        if not path.is_file() or any(p in {'.build','Build','artifacts','xcuserdata','__pycache__'} for p in path.relative_to(root).parts):
            continue
        archive.write(path,Path('CookFlowApple')/path.relative_to(root))
print(destination)
print('Source files:',len(zipfile.ZipFile(destination).namelist()),'ZIP bytes:',destination.stat().st_size)
