#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p artifacts
watch_device_id="$(xcrun simctl list devices available -j | python3 -c 'import sys,json; d=json.load(sys.stdin); print(next((v["udid"] for k,vs in d["devices"].items() if "watchOS" in k for v in vs if v.get("isAvailable",False)),""))')"
if [[ -z "$watch_device_id" ]]; then
  echo "No watchOS Simulator runtime is installed on this runner; native compilation and model tests are still checked."
  exit 0
fi
xcrun simctl boot "$watch_device_id" || true
# Preview mode uses only bundled example data and never connects to a phone.
# Keep simulator startup bounded; cold iPhone migration is unnecessary here.
python3 -c 'import subprocess,sys; subprocess.run(["xcrun","simctl","bootstatus",sys.argv[1],"-b"],check=True,timeout=240)' "$watch_device_id"
xcrun simctl install "$watch_device_id" Build/Build/Products/Debug-watchsimulator/CookFlowWatch.app
xcrun simctl launch "$watch_device_id" com.joeldreimer13.cookflow.watchapp --preview
sleep 3
xcrun simctl io "$watch_device_id" screenshot artifacts/CookFlow-Watch-home.png
xcrun simctl terminate "$watch_device_id" com.joeldreimer13.cookflow.watchapp || true
xcrun simctl launch "$watch_device_id" com.joeldreimer13.cookflow.watchapp --preview --shopping
sleep 2
xcrun simctl io "$watch_device_id" screenshot artifacts/CookFlow-Watch-shopping.png
xcrun simctl terminate "$watch_device_id" com.joeldreimer13.cookflow.watchapp || true
xcrun simctl launch "$watch_device_id" com.joeldreimer13.cookflow.watchapp --preview --items
sleep 2
xcrun simctl io "$watch_device_id" screenshot artifacts/CookFlow-Watch-items.png
