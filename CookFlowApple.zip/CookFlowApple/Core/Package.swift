// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "CookFlowCore",
    platforms: [.macOS(.v13), .iOS(.v17), .watchOS(.v10)],
    products: [.library(name: "CookFlowCore", targets: ["CookFlowCore"])],
    targets: [
        .target(name: "CookFlowCore"),
        .testTarget(name: "CookFlowCoreTests", dependencies: ["CookFlowCore"])
    ]
)
