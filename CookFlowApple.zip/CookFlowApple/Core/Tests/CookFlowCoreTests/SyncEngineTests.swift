import XCTest
@testable import CookFlowCore

final class SyncEngineTests: XCTestCase {
    func state() -> CookFlowState {
        CookFlowState(
            recipe: CookingRecipe(title: "Chili", sections: [
                CookingSection(id: "prep", title: "Prep", collapsed: false, steps: [
                    CookingStep(id: "chop", text: "Chop onion", done: false),
                    CookingStep(id: "cook", text: "Cook chili", done: false)
                ])
            ]),
            shopping: ShoppingList(version: 1, collapsed: false, lastStore: "walmart", stores: [
                ShoppingStore(id: "walmart", name: "Walmart", items: [
                    ShoppingItem(id: "spinach", text: "Fresh spinach", done: false),
                    ShoppingItem(id: "yogurt", text: "Greek yogurt", done: false)
                ], collapsed: false)
            ])
        )
    }

    func record() -> PhoneRecord { PhoneRecord(state: state(), documentID: "doc", now: 100) }

    func command(id: String = "change-1", sequence: Int64 = 1, base: Int64 = 0,
                 item: String = "spinach", done: Bool = true, target: CheckTarget = .shopping) -> CheckMutation {
        CheckMutation(id: id, documentID: "doc", clientID: "watch", sequence: sequence,
            baseRevision: base, target: target, itemID: item, done: done)
    }

    func testIndependentProgressAndEmptyList() {
        var value = state()
        value.setChecked(target: .shopping, itemID: "spinach", done: true)
        XCTAssertEqual(value.shopping.progress.percent, 50)
        XCTAssertEqual(value.recipe.progress.percent, 0)
        value.shopping.stores.removeAll()
        XCTAssertEqual(value.shopping.progress.percent, 0)
        XCTAssertEqual(value.shopping.progress.fraction, 0)
    }

    func testExplicitChangeIsIdempotent() {
        var phone = record()
        XCTAssertEqual(phone.apply(command(), now: 101), .applied)
        XCTAssertEqual(phone.apply(command(), now: 102), .duplicate)
        XCTAssertEqual(phone.snapshot.revision, 1)
        XCTAssertEqual(phone.snapshot.state.shopping.progress.completed, 1)
        XCTAssertTrue(phone.snapshot.acknowledged.contains("change-1"))
    }

    func testDifferentItemsMergeWhileDisconnected() throws {
        var phone = record(), edited = state()
        edited.setChecked(target: .shopping, itemID: "yogurt", done: true)
        try phone.acceptWebState(edited, now: 101)
        XCTAssertEqual(phone.apply(command(), now: 102), .applied)
        XCTAssertEqual(phone.snapshot.state.shopping.progress.completed, 2)
    }

    func testNewerPhoneChangeWinsOverStaleWatchChange() throws {
        var phone = record(), edited = state()
        edited.setChecked(target: .shopping, itemID: "spinach", done: true)
        try phone.acceptWebState(edited, now: 101)
        edited.setChecked(target: .shopping, itemID: "spinach", done: false)
        try phone.acceptWebState(edited, now: 102)
        XCTAssertEqual(phone.apply(command(), now: 103), .conflict)
        XCTAssertEqual(phone.snapshot.state.checkedValue(target: .shopping, itemID: "spinach"), false)
        XCTAssertTrue(phone.snapshot.acknowledged.contains("change-1"))
        XCTAssertFalse(phone.snapshot.notices.isEmpty)
    }

    func testStaleWebSnapshotPreservesUnrelatedWatchCheckbox() throws {
        var phone = record()
        let webBaseline = state()
        phone.apply(command(), now: 101)
        var webEdit = webBaseline
        webEdit.setChecked(target: .shopping, itemID: "yogurt", done: true)
        try phone.acceptWebState(webEdit, basedOn: webBaseline, now: 102)
        XCTAssertEqual(phone.snapshot.state.shopping.progress.completed, 2)
    }

    func testExplicitPhoneIntentSupersedesWatchEvenIfValueAlreadyMatches() throws {
        var phone = record()
        let webBaseline = state()
        phone.apply(command(), now: 101)
        var webEdit = webBaseline
        webEdit.setChecked(target: .shopping, itemID: "spinach", done: true)
        try phone.acceptWebState(webEdit, basedOn: webBaseline, now: 102)
        XCTAssertEqual(phone.apply(command(id: "older-offline-intent", sequence: 2, done: false), now: 103), .conflict)
        XCTAssertEqual(phone.snapshot.state.checkedValue(target: .shopping, itemID: "spinach"), true)
    }

    func testRepeatedOfflineTapsFromWatchKeepLatestIntent() {
        var phone = record()
        XCTAssertEqual(phone.apply(command(), now: 101), .applied)
        XCTAssertEqual(phone.apply(command(id: "change-2", sequence: 2, done: false), now: 102), .applied)
        XCTAssertEqual(phone.snapshot.state.checkedValue(target: .shopping, itemID: "spinach"), false)
    }

    func testOutOfOrderOldWatchCommandCannotUndoNewerCommand() {
        var phone = record()
        XCTAssertEqual(phone.apply(command(id: "new", sequence: 2, done: false), now: 101), .applied)
        XCTAssertEqual(phone.apply(command(id: "old", sequence: 1, done: true), now: 102), .superseded)
        XCTAssertEqual(phone.snapshot.state.checkedValue(target: .shopping, itemID: "spinach"), false)
    }

    func testRemovedItemIsNotRecreatedByWatch() throws {
        var phone = record(), edited = state()
        edited.shopping.stores[0].items.removeFirst()
        try phone.acceptWebState(edited, now: 101)
        XCTAssertEqual(phone.apply(command(), now: 102), .missingItem)
        XCTAssertNil(phone.snapshot.state.checkedValue(target: .shopping, itemID: "spinach"))
        XCTAssertEqual(phone.snapshot.state.shopping.progress.total, 1)
    }

    func testNewImportRejectsCommandsForPreviousLists() throws {
        var phone = record()
        try phone.replace(with: state(), now: 101)
        XCTAssertNotEqual(phone.snapshot.documentID, "doc")
        XCTAssertEqual(phone.apply(command(), now: 102), .wrongDocument)
        XCTAssertEqual(phone.snapshot.state.shopping.progress.completed, 0)
    }

    func testReplicaOptimisticallyChecksAndCoalescesOneItem() {
        var watch = WatchReplica(clientID: "watch", canonical: record().snapshot)
        watch.enqueue(target: .shopping, itemID: "spinach", done: true)
        XCTAssertEqual(watch.displayedState?.shopping.progress.percent, 50)
        watch.enqueue(target: .shopping, itemID: "spinach", done: false)
        XCTAssertEqual(watch.pending.count, 1)
        XCTAssertEqual(watch.pending[0].sequence, 2)
        XCTAssertEqual(watch.displayedState?.shopping.progress.percent, 0)
    }

    func testCanonicalRefreshDoesNotEraseUnacknowledgedWatchChanges() throws {
        var phone = record(), watch = WatchReplica(clientID: "watch", canonical: record().snapshot)
        watch.enqueue(target: .shopping, itemID: "spinach", done: true)
        var web = state()
        web.setChecked(target: .cooking, itemID: "chop", done: true)
        try phone.acceptWebState(web, now: 101)
        watch.receive(phone.snapshot)
        XCTAssertEqual(watch.displayedState?.shopping.progress.completed, 1)
        XCTAssertEqual(watch.displayedState?.recipe.progress.completed, 1)
        XCTAssertEqual(watch.pending.count, 1)
    }

    func testAcknowledgementClearsOutbox() {
        var phone = record(), watch = WatchReplica(clientID: "watch", canonical: record().snapshot)
        let change = watch.enqueue(target: .shopping, itemID: "spinach", done: true)!
        phone.apply(change, now: 101)
        watch.receive(phone.snapshot)
        XCTAssertTrue(watch.pending.isEmpty)
        XCTAssertEqual(watch.displayedState?.shopping.progress.completed, 1)
    }

    func testSameRevisionAcknowledgementStillClearsRejectedCommand() throws {
        var phone = record(), edited = state()
        edited.setChecked(target: .shopping, itemID: "spinach", done: true)
        try phone.acceptWebState(edited, now: 101)
        var watch = WatchReplica(clientID: "watch", canonical: record().snapshot)
        let change = watch.enqueue(target: .shopping, itemID: "spinach", done: false)!
        watch.receive(phone.snapshot)
        let revision = phone.snapshot.revision
        XCTAssertEqual(phone.apply(change, now: 102), .conflict)
        XCTAssertEqual(phone.snapshot.revision, revision)
        XCTAssertNotNil(watch.receive(phone.snapshot))
        XCTAssertTrue(watch.pending.isEmpty)
        XCTAssertEqual(watch.displayedState?.shopping.progress.completed, 1)
    }

    func testOlderSnapshotAndOldDocumentCannotRollBackReplica() throws {
        var phone = record(), watch = WatchReplica(clientID: "watch", canonical: record().snapshot)
        let old = phone.snapshot
        phone.apply(command(), now: 101)
        watch.receive(phone.snapshot)
        watch.receive(old)
        XCTAssertEqual(watch.canonical?.revision, 1)
        try phone.replace(with: state(), now: 102)
        watch.receive(phone.snapshot)
        watch.receive(old)
        XCTAssertEqual(watch.canonical?.documentID, phone.snapshot.documentID)
    }

    func testBackupAndPersistentOutboxRoundTrip() throws {
        let backup = CookFlowBackup(state: state(), now: 100)
        XCTAssertEqual(try CookFlowBackup.read(CookFlowWire.encode(backup)), state())
        var watch = WatchReplica(clientID: "watch", canonical: record().snapshot)
        watch.enqueue(target: .cooking, itemID: "chop", done: true)
        let restored = try JSONDecoder().decode(WatchReplica.self, from: CookFlowWire.encode(watch))
        XCTAssertEqual(restored.pending, watch.pending)
        XCTAssertEqual(restored.nextSequence, 1)
        XCTAssertEqual(restored.displayedState?.recipe.progress.percent, 50)
    }

    func testActualBrowserExportDecodesInNativeApp() throws {
        let path = try XCTUnwrap(Bundle.module.url(forResource: "browser-backup", withExtension: "json", subdirectory: "Fixtures"))
        let state = try CookFlowBackup.read(Data(contentsOf: path))
        XCTAssertEqual(state.shopping.stores.map(\.name), ["Walmart", "WinCo", "Target"])
        XCTAssertEqual(state.shopping.progress.total, 7)
        XCTAssertEqual(state.shopping.progress.completed, 2)
        XCTAssertEqual(state.recipe.progress.total, 34)
        XCTAssertEqual(state.recipe.progress.completed, 1)
        XCTAssertEqual(try CookFlowBackup.read(CookFlowWire.encode(CookFlowBackup(state: state))), state)
    }

    func testInvalidDuplicateIdentifiersAreRejected() {
        var invalid = state()
        invalid.shopping.stores[0].items[1].id = "spinach"
        XCTAssertThrowsError(try invalid.validate())
    }

    func testLargeSnapshotSurvivesFileTransportEncoding() throws {
        var value = state()
        value.recipe.sections[0].steps[0].text = String(repeating: "Step detail. ", count: 2_000)
        let snapshot = PhoneRecord(state: value, now: 100).snapshot
        var expanded = snapshot
        expanded.acknowledged = (0..<256).map { _ in UUID().uuidString }
        expanded.state.recipe.sections[0].steps[1].text = String(repeating: "More detail. ", count: 2_000)
        let data = try CookFlowWire.encode(expanded)
        XCTAssertGreaterThan(data.count, CookFlowWire.inlineLimit)
        XCTAssertEqual(try CookFlowWire.snapshot(data), expanded)
    }

    func libraryState() -> CookFlowState {
        var value = state()
        let first = SavedRecipe(id: "salad", folderId: "prep", recipe: value.recipe, createdAt: 10, updatedAt: 10)
        let other = CookingRecipe(title: "Breakfast", sections: [CookingSection(id: "breakfast-section", title: "Prepare", collapsed: false,
            steps: [CookingStep(id: "yogurt", text: "Add Greek yogurt", done: false)])])
        value.library = RecipeLibrary(activeRecipeId: first.id, folders: [RecipeFolder(id: "prep", name: "Meal prep")], recipes: [
            first, SavedRecipe(id: "breakfast", recipe: other, createdAt: 11, updatedAt: 11)
        ])
        return value
    }

    func testLegacyBackupKeepsCurrentRecipeAndProgressInLibrary() throws {
        let path = try XCTUnwrap(Bundle.module.url(forResource: "browser-backup", withExtension: "json", subdirectory: "Fixtures"))
        let decoded = try CookFlowBackup.read(Data(contentsOf: path))
        XCTAssertEqual(decoded.library.recipes.count, 1)
        XCTAssertEqual(decoded.library.recipes.first?.recipe, decoded.recipe)
        XCTAssertEqual(decoded.library.recipes.first?.recipe.progress.completed, 1)
        XCTAssertEqual(decoded.library.activeRecipeId, "legacy-current-recipe")
    }

    func testLibraryBackupPreservesFoldersAndAllRecipes() throws {
        let value = libraryState()
        let backup = CookFlowBackup(state: value, now: 100)
        XCTAssertEqual(backup.schemaVersion, 2)
        XCTAssertEqual(try CookFlowBackup.read(CookFlowWire.encode(backup)), value)
        XCTAssertEqual(try JSONDecoder().decode(PhoneRecord.self, from: CookFlowWire.encode(PhoneRecord(state: value))).snapshot.state, value)
    }

    func testActualBrowserLibraryBackupDecodesAndKeepsProgress() throws {
        let path = try XCTUnwrap(Bundle.module.url(forResource: "library-backup", withExtension: "json", subdirectory: "Fixtures"))
        let value = try CookFlowBackup.read(Data(contentsOf: path))
        XCTAssertEqual(value.library.recipes.count, 2)
        XCTAssertEqual(value.library.folders.map(\.name), ["Weekly prep"])
        XCTAssertEqual(value.recipe.title, "Lemon Quinoa Salad")
        XCTAssertEqual(value.recipe.progress.total, 5)
        XCTAssertEqual(value.recipe.progress.completed, 1)
        XCTAssertEqual(value.shopping.progress.completed, 2)
        XCTAssertEqual(try CookFlowBackup.read(CookFlowWire.encode(CookFlowBackup(state: value))), value)
    }

    func testInvalidFolderAndDuplicateArchivedStepAreRejected() throws {
        var value = libraryState()
        value.library.recipes[0].folderId = "missing-folder"
        XCTAssertThrowsError(try value.validate())
        value = libraryState()
        value.library.recipes[1].recipe.sections[0].steps[0].id = "chop"
        XCTAssertThrowsError(try value.validate())
    }

    func testWatchChangeUpdatesSavedActiveRecipeProgress() {
        var phone = PhoneRecord(state: libraryState(), documentID: "doc", now: 100)
        XCTAssertEqual(phone.apply(command(item: "chop", target: .cooking), now: 101), .applied)
        XCTAssertEqual(phone.snapshot.state.recipe.progress.completed, 1)
        XCTAssertEqual(phone.snapshot.state.library.recipes[0].recipe.progress.completed, 1)
        XCTAssertEqual(phone.snapshot.state.library.recipes[1].recipe.progress.completed, 0)
    }

    func testRecipeSwitchPreservesWatchChangeToPreviousRecipe() throws {
        let baseline = libraryState()
        var phone = PhoneRecord(state: baseline, documentID: "doc", now: 100)
        XCTAssertEqual(phone.apply(command(item: "chop", target: .cooking), now: 101), .applied)
        var web = baseline
        web.library.activeRecipeId = "breakfast"
        web.recipe = web.library.recipes[1].recipe
        try phone.acceptWebState(web, basedOn: baseline, now: 102)
        XCTAssertEqual(phone.snapshot.state.recipe.title, "Breakfast")
        XCTAssertEqual(phone.snapshot.state.library.recipes[0].recipe.progress.completed, 1)
    }

    func testQueuedWatchEditCanFinishInSavedRecipeAfterPhoneSwitch() throws {
        let value = libraryState()
        var phone = PhoneRecord(state: value, documentID: "doc", now: 100)
        var watch = WatchReplica(clientID: "watch", canonical: phone.watchSnapshot)
        let edit = try XCTUnwrap(watch.enqueue(target: .cooking, itemID: "chop", done: true))
        var web = value
        web.library.activeRecipeId = "breakfast"
        web.recipe = web.library.recipes[1].recipe
        try phone.acceptWebState(web, basedOn: value, now: 101)
        watch.receive(phone.watchSnapshot)
        XCTAssertEqual(watch.pending.count, 1)
        XCTAssertEqual(phone.apply(edit, now: 102), .applied)
        XCTAssertEqual(phone.snapshot.state.recipe.title, "Breakfast")
        XCTAssertEqual(phone.snapshot.state.library.recipes[0].recipe.progress.completed, 1)
        watch.receive(phone.watchSnapshot)
        XCTAssertTrue(watch.pending.isEmpty)
    }

    func testWatchSnapshotIncludesCurrentRecipeWithoutEntireLibrary() {
        let phone = PhoneRecord(state: libraryState(), documentID: "doc", now: 100)
        XCTAssertEqual(phone.watchSnapshot.state.recipe, phone.snapshot.state.recipe)
        XCTAssertEqual(phone.watchSnapshot.state.shopping, phone.snapshot.state.shopping)
        XCTAssertTrue(phone.watchSnapshot.state.library.recipes.isEmpty)
        XCTAssertEqual(phone.snapshot.state.library.recipes.count, 2)
    }
}
