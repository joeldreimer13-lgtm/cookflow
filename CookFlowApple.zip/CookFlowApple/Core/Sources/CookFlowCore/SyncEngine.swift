import Foundation

struct ItemClock: Codable, Equatable {
    var revision: Int64
    var clientID: String
    var sequence: Int64
}

enum ApplyResult: String {
    case applied, duplicate, superseded, conflict, missingItem, wrongDocument, invalid
}

/// The iPhone assigns revisions. Watch sends idempotent, explicit checkbox changes.
/// A newer iPhone edit wins over a stale offline change to that same checkbox.
struct PhoneRecord: Codable {
    var snapshot: SyncSnapshot
    var clocks: [String: ItemClock] = [:]
    var processed: [String] = []

    /// The Watch only needs the current recipe and shopping list, not the archive.
    var watchSnapshot: SyncSnapshot {
        var result = snapshot
        result.state.library = .empty
        return result
    }

    init(state: CookFlowState, documentID: String = UUID().uuidString, now: Double = Date().timeIntervalSince1970) {
        snapshot = SyncSnapshot(documentID: documentID, revision: 0, modifiedAt: now, state: state)
    }

    mutating func replace(with state: CookFlowState, now: Double = Date().timeIntervalSince1970) throws {
        try state.validate()
        let nextRevision = snapshot.revision + 1
        self = PhoneRecord(state: state, now: now)
        snapshot.revision = nextRevision
    }

    @discardableResult
    mutating func acceptWebState(_ state: CookFlowState, basedOn base: CookFlowState? = nil, now: Double = Date().timeIntervalSince1970) throws -> Bool {
        try state.validate()
        if let base { try base.validate() }
        let old = snapshot.state.checkValues
        let proposed = state.checkValues
        let baseline = base?.checkValues ?? old
        let intended = Set(proposed.keys.filter { baseline[$0] != proposed[$0] })
        var merged = state
        // A full WebView snapshot may have been composed just before a Watch update.
        // Preserve current flags unless the user actually changed that checkbox.
        if base != nil {
            for saved in merged.library.recipes.indices {
                for section in merged.library.recipes[saved].recipe.sections.indices {
                    for step in merged.library.recipes[saved].recipe.sections[section].steps.indices {
                        let id = merged.library.recipes[saved].recipe.sections[section].steps[step].id
                        if !intended.contains("cooking:" + id), let current = snapshot.state.checkedValue(target: .cooking, itemID: id) {
                            merged.library.recipes[saved].recipe.sections[section].steps[step].done = current
                        }
                    }
                }
            }
            for step in state.recipe.sections.flatMap(\.steps) where !intended.contains("cooking:" + step.id) {
                if let current = snapshot.state.checkedValue(target: .cooking, itemID: step.id) {
                    merged.setChecked(target: .cooking, itemID: step.id, done: current)
                }
            }
            for item in state.shopping.stores.flatMap(\.items) where !intended.contains("shopping:" + item.id) {
                if let current = snapshot.state.checkedValue(target: .shopping, itemID: item.id) {
                    merged.setChecked(target: .shopping, itemID: item.id, done: current)
                }
            }
        }
        merged.library.saveActive(merged.recipe, now: now)
        guard merged != snapshot.state || !intended.isEmpty else { return false }
        let new = merged.checkValues
        snapshot.revision += 1
        snapshot.modifiedAt = now
        snapshot.state = merged
        clocks = clocks.filter { new[$0.key] != nil }
        for (key, value) in new where old[key] != value || intended.contains(key) {
            clocks[key] = ItemClock(revision: snapshot.revision, clientID: "phone", sequence: 0)
        }
        return true
    }

    @discardableResult
    mutating func apply(_ command: CheckMutation, now: Double = Date().timeIntervalSince1970) -> ApplyResult {
        guard command.documentID == snapshot.documentID else { return .wrongDocument }
        if processed.contains(command.id) {
            acknowledge(command.id, now: now)
            return .duplicate
        }
        processed.append(command.id)
        if processed.count > 4_096 { processed.removeFirst(processed.count - 4_096) }
        defer { acknowledge(command.id, now: now) }
        guard command.sequence > 0, command.baseRevision >= 0, command.baseRevision <= snapshot.revision,
              !command.clientID.isEmpty, command.clientID.count <= 128 else { return .invalid }
        guard snapshot.state.checkedValue(target: command.target, itemID: command.itemID) != nil else {
            notice(command.id, "An item was removed on iPhone. Your latest list is shown.")
            return .missingItem
        }
        if let clock = clocks[command.fieldKey] {
            if clock.clientID == command.clientID {
                if command.sequence <= clock.sequence { return .superseded }
            } else if clock.revision > command.baseRevision {
                notice(command.id, "Kept a newer iPhone change to this item.")
                return .conflict
            }
        }
        snapshot.state.setChecked(target: command.target, itemID: command.itemID, done: command.done)
        snapshot.revision += 1
        snapshot.modifiedAt = now
        clocks[command.fieldKey] = ItemClock(revision: snapshot.revision, clientID: command.clientID, sequence: command.sequence)
        return .applied
    }

    private mutating func acknowledge(_ id: String, now: Double) {
        snapshot.acknowledged.removeAll { $0 == id }
        snapshot.acknowledged.append(id)
        if snapshot.acknowledged.count > 256 { snapshot.acknowledged.removeFirst(snapshot.acknowledged.count - 256) }
        snapshot.modifiedAt = now
    }

    private mutating func notice(_ id: String, _ text: String) {
        snapshot.notices.append(CommandNotice(id: id, message: text))
        if snapshot.notices.count > 12 { snapshot.notices.removeFirst(snapshot.notices.count - 12) }
    }
}

struct WatchReplica: Codable {
    var clientID: String
    var nextSequence: Int64 = 0
    var canonical: SyncSnapshot?
    var pending: [CheckMutation] = []

    init(clientID: String = UUID().uuidString, canonical: SyncSnapshot? = nil) {
        self.clientID = clientID
        self.canonical = canonical
    }

    var displayedState: CookFlowState? {
        guard var state = canonical?.state else { return nil }
        for command in pending.sorted(by: { $0.sequence < $1.sequence }) {
            state.setChecked(target: command.target, itemID: command.itemID, done: command.done)
        }
        return state
    }

    @discardableResult
    mutating func enqueue(target: CheckTarget, itemID: String, done: Bool) -> CheckMutation? {
        guard let canonical, canonical.state.checkedValue(target: target, itemID: itemID) != nil else { return nil }
        nextSequence += 1
        let command = CheckMutation(id: UUID().uuidString, documentID: canonical.documentID,
            clientID: clientID, sequence: nextSequence, baseRevision: canonical.revision,
            target: target, itemID: itemID, done: done)
        pending.removeAll { $0.target == target && $0.itemID == itemID }
        pending.append(command)
        return command
    }

    /// Same-revision snapshots may contain new acknowledgements and must still be read.
    @discardableResult
    mutating func receive(_ incoming: SyncSnapshot) -> String? {
        if let current = canonical {
            if incoming.documentID == current.documentID {
                guard incoming.revision >= current.revision else { return nil }
            } else {
                guard incoming.modifiedAt >= current.modifiedAt else { return nil }
                pending.removeAll()
            }
        }
        let pendingIDs = Set(pending.map(\.id))
        let message = incoming.notices.last(where: { pendingIDs.contains($0.id) })?.message
        let acknowledged = Set(incoming.acknowledged)
        canonical = incoming
        pending.removeAll {
            $0.documentID != incoming.documentID || acknowledged.contains($0.id)
        }
        return message
    }
}
