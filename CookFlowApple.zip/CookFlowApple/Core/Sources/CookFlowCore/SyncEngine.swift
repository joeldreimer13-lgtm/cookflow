import Foundation

struct ItemClock: Codable, Equatable {
    var revision: Int64
    var clientID: String
    var sequence: Int64
}

enum ApplyResult: String {
    case applied, duplicate, superseded, conflict, missingItem, wrongDocument, invalid
}

/// The iPhone assigns revisions. Watch sends idempotent, explicit checkbox changes.
/// A newer iPhone edit wins over a stale offline change to that same checkbox.
struct PhoneRecord: Codable {
    var snapshot: SyncSnapshot
    var clocks: [String: ItemClock] = [:]
    var processed: [String] = []

    init(state: CookFlowState, documentID: String = UUID().uuidString, now: Double = Date().timeIntervalSince1970) {
        snapshot = SyncSnapshot(documentID: documentID, revision: 0, modifiedAt: now, state: state)
    }

    mutating func replace(with state: CookFlowState, now: Double = Date().timeIntervalSince1970) throws {
        try state.validate()
        let nextRevision = snapshot.revision + 1
        self = PhoneRecord(state: state, now: now)
        snapshot.revision = nextRevision
    }

    @discardableResult
    mutating func acceptWebState(_ state: CookFlowState, now: Double = Date().timeIntervalSince1970) throws -> Bool {
        try state.validate()
        guard state != snapshot.state else { return false }
        let old = snapshot.state.checkValues
        let new = state.checkValues
        snapshot.revision += 1
        snapshot.modifiedAt = now
        snapshot.state = state
        clocks = clocks.filter { new[$0.key] != nil }
        for (key, value) in new where old[key] != value {
            clocks[key] = ItemClock(revision: snapshot.revision, clientID: "phone", sequence: 0)
        }
        return true
    }

    @discardableResult
    mutating func apply(_ command: CheckMutation, now: Double = Date().timeIntervalSince1970) -> ApplyResult {
        guard command.documentID == snapshot.documentID else { return .wrongDocument }
        if processed.contains(command.id) {
            acknowledge(command.id, now: now)
            return .duplicate
        }
        processed.append(command.id)
        if processed.count > 4_096 { processed.removeFirst(processed.count - 4_096) }
        defer { acknowledge(command.id, now: now) }
        guard command.sequence > 0, command.baseRevision >= 0, command.baseRevision <= snapshot.revision,
              !command.clientID.isEmpty, command.clientID.count <= 128 else { return .invalid }
        guard snapshot.state.checkedValue(target: command.target, itemID: command.itemID) != nil else {
            notice(command.id, "An item was removed on iPhone. Your latest list is shown.")
            return .missingItem
        }
        if let clock = clocks[command.fieldKey] {
            if clock.clientID == command.clientID {
                if command.sequence <= clock.sequence { return .superseded }
            } else if clock.revision > command.baseRevision {
                notice(command.id, "Kept a newer iPhone change to this item.")
                return .conflict
            }
        }
        snapshot.state.setChecked(target: command.target, itemID: command.itemID, done: command.done)
        snapshot.revision += 1
        snapshot.modifiedAt = now
        clocks[command.fieldKey] = ItemClock(revision: snapshot.revision, clientID: command.clientID, sequence: command.sequence)
        return .applied
    }

    private mutating func acknowledge(_ id: String, now: Double) {
        snapshot.acknowledged.removeAll { $0 == id }
        snapshot.acknowledged.append(id)
        if snapshot.acknowledged.count > 256 { snapshot.acknowledged.removeFirst(snapshot.acknowledged.count - 256) }
        snapshot.modifiedAt = now
    }

    private mutating func notice(_ id: String, _ text: String) {
        snapshot.notices.append(CommandNotice(id: id, message: text))
        if snapshot.notices.count > 12 { snapshot.notices.removeFirst(snapshot.notices.count - 12) }
    }
}

struct WatchReplica: Codable {
    var clientID: String
    var nextSequence: Int64 = 0
    var canonical: SyncSnapshot?
    var pending: [CheckMutation] = []

    init(clientID: String = UUID().uuidString, canonical: SyncSnapshot? = nil) {
        self.clientID = clientID
        self.canonical = canonical
    }

    var displayedState: CookFlowState? {
        guard var state = canonical?.state else { return nil }
        for command in pending.sorted(by: { $0.sequence < $1.sequence }) {
            state.setChecked(target: command.target, itemID: command.itemID, done: command.done)
        }
        return state
    }

    @discardableResult
    mutating func enqueue(target: CheckTarget, itemID: String, done: Bool) -> CheckMutation? {
        guard let canonical, canonical.state.checkedValue(target: target, itemID: itemID) != nil else { return nil }
        nextSequence += 1
        let command = CheckMutation(id: UUID().uuidString, documentID: canonical.documentID,
            clientID: clientID, sequence: nextSequence, baseRevision: canonical.revision,
            target: target, itemID: itemID, done: done)
        pending.removeAll { $0.target == target && $0.itemID == itemID }
        pending.append(command)
        return command
    }

    /// Same-revision snapshots may contain new acknowledgements and must still be read.
    @discardableResult
    mutating func receive(_ incoming: SyncSnapshot) -> String? {
        if let current = canonical {
            if incoming.documentID == current.documentID {
                guard incoming.revision >= current.revision else { return nil }
            } else {
                guard incoming.modifiedAt >= current.modifiedAt else { return nil }
                pending.removeAll()
            }
        }
        let pendingIDs = Set(pending.map(\.id))
        let message = incoming.notices.last(where: { pendingIDs.contains($0.id) })?.message
        let acknowledged = Set(incoming.acknowledged)
        canonical = incoming
        pending.removeAll {
            $0.documentID != incoming.documentID || acknowledged.contains($0.id) ||
                incoming.state.checkedValue(target: $0.target, itemID: $0.itemID) == nil
        }
        return message
    }
}
