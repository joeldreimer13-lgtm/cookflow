import Foundation

struct CookingStep: Codable, Equatable, Identifiable {
    var id: String
    var text: String
    var done: Bool
}

struct CookingSection: Codable, Equatable, Identifiable {
    var id: String
    var title: String
    var collapsed: Bool
    var steps: [CookingStep]

    var progress: CompletionProgress { CompletionProgress(values: steps.map(\.done)) }
}

struct CookingRecipe: Codable, Equatable {
    var title: String
    var sections: [CookingSection]

    var progress: CompletionProgress {
        CompletionProgress(values: sections.flatMap { $0.steps.map(\.done) })
    }
}

struct ShoppingItem: Codable, Equatable, Identifiable {
    var id: String
    var text: String
    var done: Bool
}

struct ShoppingStore: Codable, Equatable, Identifiable {
    var id: String
    var name: String
    var items: [ShoppingItem]
    var collapsed: Bool

    var progress: CompletionProgress { CompletionProgress(values: items.map(\.done)) }
}

struct ShoppingList: Codable, Equatable {
    var version: Int
    var collapsed: Bool
    var lastStore: String
    var stores: [ShoppingStore]

    var progress: CompletionProgress {
        CompletionProgress(values: stores.flatMap { $0.items.map(\.done) })
    }
}

struct CompletionProgress: Equatable {
    var completed: Int
    var total: Int

    init(values: [Bool]) {
        total = values.count
        completed = values.filter { $0 }.count
    }

    var fraction: Double { total == 0 ? 0 : Double(completed) / Double(total) }
    var percent: Int { Int((fraction * 100).rounded()) }
    var countText: String { "\(completed) of \(total)" }
}

enum CheckTarget: String, Codable { case cooking, shopping }

struct RecipeFolder: Codable, Equatable, Identifiable {
    var id: String
    var name: String
}

struct SavedRecipe: Codable, Equatable, Identifiable {
    var id: String
    var folderId: String?
    var recipe: CookingRecipe
    var createdAt: Double
    var updatedAt: Double
}

struct RecipeLibrary: Codable, Equatable {
    var version = 1
    var activeRecipeId: String?
    var folders: [RecipeFolder] = []
    var recipes: [SavedRecipe] = []

    static var empty: RecipeLibrary { RecipeLibrary() }

    static func migrating(_ recipe: CookingRecipe) -> RecipeLibrary {
        guard !recipe.sections.flatMap(\.steps).isEmpty else { return .empty }
        let id = "legacy-current-recipe"
        return RecipeLibrary(activeRecipeId: id, recipes: [
            SavedRecipe(id: id, recipe: recipe, createdAt: 0, updatedAt: 0)
        ])
    }

    mutating func saveActive(_ recipe: CookingRecipe, now: Double) {
        guard let index = recipes.firstIndex(where: { $0.id == activeRecipeId }),
              recipes[index].recipe != recipe else { return }
        recipes[index].recipe = recipe
        recipes[index].updatedAt = now
    }

    func validate() throws {
        guard version == 1, folders.count <= 200, recipes.count <= 1_000 else {
            throw DocumentError.invalid("This recipe library is too large or needs a newer CookFlow version.")
        }
        let folderIDs = folders.map(\.id), recipeIDs = recipes.map(\.id)
        for ids in [folderIDs, recipeIDs] {
            guard Set(ids).count == ids.count, ids.allSatisfy({ !$0.isEmpty && $0.count <= 128 }) else {
                throw DocumentError.invalid("The recipe library has duplicate or missing identifiers.")
            }
        }
        guard folders.allSatisfy({ !$0.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && $0.name.count <= 80 }),
              activeRecipeId == nil || recipeIDs.contains(activeRecipeId!),
              recipes.allSatisfy({ ($0.folderId == nil || folderIDs.contains($0.folderId!)) && $0.createdAt.isFinite && $0.updatedAt.isFinite }) else {
            throw DocumentError.invalid("A recipe or folder reference is invalid.")
        }
        var allRecipeIDs = Set<String>()
        for saved in recipes {
            let ids = saved.recipe.sections.map(\.id) + saved.recipe.sections.flatMap { $0.steps.map(\.id) }
            guard ids.allSatisfy({ allRecipeIDs.insert($0).inserted }) else {
                throw DocumentError.invalid("Saved recipes must have separate item identifiers.")
            }
            // Validate a stored recipe with the same rules as the active checklist.
            let state = CookFlowState(recipe: saved.recipe,
                shopping: ShoppingList(version: 1, collapsed: false, lastStore: "", stores: []))
            try state.validate(includeLibrary: false)
        }
    }
}

struct CookFlowState: Codable, Equatable {
    var recipe: CookingRecipe
    var shopping: ShoppingList
    var library: RecipeLibrary

    init(recipe: CookingRecipe, shopping: ShoppingList, library: RecipeLibrary = .empty) {
        self.recipe = recipe
        self.shopping = shopping
        self.library = library
    }

    private enum CodingKeys: String, CodingKey { case recipe, shopping, library }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        recipe = try values.decode(CookingRecipe.self, forKey: .recipe)
        shopping = try values.decode(ShoppingList.self, forKey: .shopping)
        library = try values.decodeIfPresent(RecipeLibrary.self, forKey: .library) ?? .migrating(recipe)
    }

    func checkedValue(target: CheckTarget, itemID: String) -> Bool? {
        switch target {
        case .cooking:
            return recipe.sections.lazy.flatMap(\.steps).first { $0.id == itemID }?.done ??
                library.recipes.lazy.flatMap { $0.recipe.sections }.flatMap(\.steps).first { $0.id == itemID }?.done
        case .shopping:
            return shopping.stores.lazy.flatMap(\.items).first { $0.id == itemID }?.done
        }
    }

    @discardableResult
    mutating func setChecked(target: CheckTarget, itemID: String, done: Bool) -> Bool {
        switch target {
        case .cooking:
            for section in recipe.sections.indices {
                if let index = recipe.sections[section].steps.firstIndex(where: { $0.id == itemID }) {
                    recipe.sections[section].steps[index].done = done
                    library.saveActive(recipe, now: Date().timeIntervalSince1970)
                    return true
                }
            }
            // A queued Watch edit may arrive after the iPhone opens another recipe.
            for saved in library.recipes.indices {
                for section in library.recipes[saved].recipe.sections.indices {
                    if let index = library.recipes[saved].recipe.sections[section].steps.firstIndex(where: { $0.id == itemID }) {
                        library.recipes[saved].recipe.sections[section].steps[index].done = done
                        library.recipes[saved].updatedAt = Date().timeIntervalSince1970
                        return true
                    }
                }
            }
        case .shopping:
            for store in shopping.stores.indices {
                if let index = shopping.stores[store].items.firstIndex(where: { $0.id == itemID }) {
                    shopping.stores[store].items[index].done = done
                    return true
                }
            }
        }
        return false
    }

    var checkValues: [String: Bool] {
        var result: [String: Bool] = [:]
        for step in library.recipes.flatMap({ $0.recipe.sections }).flatMap(\.steps) { result["cooking:" + step.id] = step.done }
        for step in recipe.sections.flatMap(\.steps) { result["cooking:" + step.id] = step.done }
        for item in shopping.stores.flatMap(\.items) { result["shopping:" + item.id] = item.done }
        return result
    }

    func validate(includeLibrary: Bool = true) throws {
        guard shopping.version == 1 else { throw DocumentError.unsupportedVersion }
        let steps = recipe.sections.flatMap(\.steps)
        let items = shopping.stores.flatMap(\.items)
        guard recipe.sections.count <= 2_000, shopping.stores.count <= 2_000,
              steps.count <= 30_000, items.count <= 30_000 else {
            throw DocumentError.invalid("This list is too large to import.")
        }
        let recipeIDs = recipe.sections.map(\.id) + steps.map(\.id)
        let shoppingIDs = shopping.stores.map(\.id) + items.map(\.id)
        for ids in [recipeIDs, shoppingIDs] {
            guard ids.allSatisfy({ !$0.isEmpty && $0.count <= 128 }), Set(ids).count == ids.count else {
                throw DocumentError.invalid("The file contains missing or duplicate item identifiers.")
            }
        }
        guard recipe.title.count <= 1_000,
              recipe.sections.allSatisfy({ $0.title.count <= 1_000 }),
              shopping.stores.allSatisfy({ !$0.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && $0.name.count <= 1_000 }),
              steps.allSatisfy({ !$0.text.isEmpty && $0.text.count <= 30_000 }),
              items.allSatisfy({ !$0.text.isEmpty && $0.text.count <= 30_000 }) else {
            throw DocumentError.invalid("The file contains an invalid item or store name.")
        }
        if includeLibrary { try library.validate() }
    }
}

enum DocumentError: LocalizedError {
    case unsupportedVersion
    case invalid(String)

    var errorDescription: String? {
        switch self {
        case .unsupportedVersion: return "This file needs a newer version of CookFlow."
        case .invalid(let message): return message
        }
    }
}

struct CookFlowBackup: Codable {
    var format = "cookflow-backup"
    var schemaVersion = 2
    var exportedAt: Double
    var recipe: CookingRecipe
    var shopping: ShoppingList
    var library: RecipeLibrary?

    init(state: CookFlowState, now: Double = Date().timeIntervalSince1970) {
        exportedAt = now
        recipe = state.recipe
        shopping = state.shopping
        library = state.library
    }

    var state: CookFlowState { CookFlowState(recipe: recipe, shopping: shopping, library: library ?? .migrating(recipe)) }

    static func read(_ data: Data) throws -> CookFlowState {
        guard data.count <= 5 * 1_024 * 1_024 else {
            throw DocumentError.invalid("Choose a CookFlow backup smaller than 5 MB.")
        }
        let backup = try JSONDecoder().decode(Self.self, from: data)
        guard backup.format == "cookflow-backup", [1, 2].contains(backup.schemaVersion) else {
            throw DocumentError.unsupportedVersion
        }
        try backup.state.validate()
        return backup.state
    }
}

struct CheckMutation: Codable, Equatable, Identifiable {
    var id: String
    var documentID: String
    var clientID: String
    var sequence: Int64
    var baseRevision: Int64
    var target: CheckTarget
    var itemID: String
    var done: Bool

    var fieldKey: String { target.rawValue + ":" + itemID }
}

struct CommandNotice: Codable, Equatable {
    var id: String
    var message: String
}

struct SyncSnapshot: Codable, Equatable {
    var schemaVersion = 1
    var documentID: String
    var revision: Int64
    var modifiedAt: Double
    var state: CookFlowState
    var acknowledged: [String] = []
    var notices: [CommandNotice] = []
}

enum CookFlowWire {
    static let snapshotKey = "cookflow.snapshot.v1"
    static let mutationKey = "cookflow.mutation.v1"
    static let requestKey = "cookflow.request.v1"
    static let inlineLimit = 48 * 1_024

    static func encode<T: Encodable>(_ value: T) throws -> Data {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        return try encoder.encode(value)
    }

    static func snapshot(_ data: Data) throws -> SyncSnapshot {
        let value = try JSONDecoder().decode(SyncSnapshot.self, from: data)
        guard value.schemaVersion == 1, value.revision >= 0 else { throw DocumentError.unsupportedVersion }
        try value.state.validate()
        return value
    }
}
