import SwiftUI
import WatchKit

@MainActor
final class WatchAppDelegate: NSObject, WKApplicationDelegate {
    func applicationDidFinishLaunching() { _ = WatchStore.shared }
}

@main
@MainActor
struct CookFlowWatchApp: App {
    @WKApplicationDelegateAdaptor(WatchAppDelegate.self) private var delegate
    @StateObject private var store = WatchStore.shared
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup { WatchRootView(store: store) }
            .onChange(of: scenePhase) { _, phase in if phase == .active { store.refresh() } }
    }
}

enum WatchRoute: Hashable {
    case shopping, cooking, store(String), section(String)
}

struct WatchRootView: View {
    @ObservedObject var store: WatchStore
    @State private var path: [WatchRoute] = Self.initialPath()

    private static func initialPath() -> [WatchRoute] {
        let arguments = ProcessInfo.processInfo.arguments
        if arguments.contains("--preview"), arguments.contains("--items"),
           let firstStore = DeviceFiles.seed().shopping.stores.first {
            return [.shopping, .store(firstStore.id)]
        }
        return arguments.contains("--preview") && arguments.contains("--shopping") ? [.shopping] : []
    }

    var body: some View {
        NavigationStack(path: $path) {
            List {
                if let state = store.state {
                    NavigationLink(value: WatchRoute.shopping) {
                        OverviewRow(title: "Shopping", symbol: "bag", progress: state.shopping.progress, tint: .yellow)
                    }
                    NavigationLink(value: WatchRoute.cooking) {
                        OverviewRow(title: "Cooking", symbol: "fork.knife", progress: state.recipe.progress, tint: .green)
                    }
                } else {
                    Section {
                        Image(systemName: "iphone").font(.largeTitle).foregroundStyle(.green)
                        Text("Bring your lists").font(.headline)
                        Text("Open CookFlow on your paired iPhone. Your shopping and cooking checklists will appear here.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
                Section {
                    Button { store.refresh() } label: { Label("Sync now", systemImage: "arrow.triangle.2.circlepath") }
                    SyncFootnote(store: store)
                }
            }
            .navigationTitle("CookFlow")
            .navigationDestination(for: WatchRoute.self) { route in
                switch route {
                case .shopping: ShoppingStoresView(store: store)
                case .cooking: CookingSectionsView(store: store)
                case .store(let id): ShoppingItemsView(store: store, storeID: id)
                case .section(let id): CookingStepsView(store: store, sectionID: id)
                }
            }
        }
        .tint(.green)
    }
}

struct OverviewRow: View {
    var title: String
    var symbol: String
    var progress: CompletionProgress
    var tint: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack {
                Image(systemName: symbol).foregroundStyle(tint)
                Text(title).font(.headline)
                Spacer(minLength: 2)
                Text("\(progress.percent)%").font(.system(.headline, design: .rounded)).monospacedDigit()
            }
            ProgressView(value: progress.fraction).tint(tint)
            Text("\(progress.countText) complete").font(.caption2).foregroundStyle(.secondary)
        }
        .padding(.vertical, 4)
        .accessibilityElement(children: .combine)
    }
}

struct ProgressHeader: View {
    var title: String
    var progress: CompletionProgress
    var tint: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(alignment: .firstTextBaseline) {
                Text(title).font(.headline).lineLimit(2)
                Spacer(minLength: 3)
                Text("\(progress.percent)%").font(.system(.title2, design: .rounded).bold()).monospacedDigit()
            }
            ProgressView(value: progress.fraction).tint(tint)
            Text("\(progress.countText) complete").font(.caption2).foregroundStyle(.secondary)
        }
        .padding(.vertical, 3)
        .accessibilityElement(children: .combine)
    }
}

struct ShoppingStoresView: View {
    @ObservedObject var store: WatchStore
    var body: some View {
        List {
            if let shopping = store.state?.shopping {
                ProgressHeader(title: "Shopping", progress: shopping.progress, tint: .yellow)
                ForEach(shopping.stores) { item in
                    NavigationLink(value: WatchRoute.store(item.id)) {
                        VStack(alignment: .leading, spacing: 5) {
                            Text(item.name).font(.headline)
                            Text("\(item.progress.countText) bought · \(item.progress.percent)%")
                                .font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                if shopping.stores.isEmpty { Text("Add a store in the iPhone app to get started.").font(.footnote) }
            }
            SyncFootnote(store: store)
        }
        .navigationTitle("Shopping")
    }
}

struct ShoppingItemsView: View {
    @ObservedObject var store: WatchStore
    var storeID: String
    private var current: ShoppingStore? { store.state?.shopping.stores.first { $0.id == storeID } }

    var body: some View {
        List {
            if let current {
                ProgressHeader(title: current.name, progress: current.progress, tint: .yellow)
                ForEach(current.items) { item in
                    Button { store.setChecked(target: .shopping, id: item.id, done: !item.done) } label: {
                        CheckRow(text: item.text, done: item.done, tint: .yellow)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(item.text)
                    .accessibilityValue(item.done ? "Bought" : "Not bought")
                    .accessibilityHint(item.done ? "Mark as not bought" : "Mark as bought")
                }
                if current.items.isEmpty { Text("Add items for this store in the iPhone app.").font(.footnote) }
            } else { Text("This store was removed on iPhone.").font(.footnote) }
            SyncFootnote(store: store)
        }
        .navigationTitle(current?.name ?? "Store")
    }
}

struct CookingSectionsView: View {
    @ObservedObject var store: WatchStore
    var body: some View {
        List {
            if let recipe = store.state?.recipe {
                ProgressHeader(title: "Cooking", progress: recipe.progress, tint: .green)
                Text(recipe.title).font(.headline)
                ForEach(recipe.sections) { section in
                    NavigationLink(value: WatchRoute.section(section.id)) {
                        VStack(alignment: .leading, spacing: 5) {
                            Text(section.title).font(.headline)
                            Text("\(section.progress.countText) complete · \(section.progress.percent)%")
                                .font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                if recipe.sections.isEmpty { Text("Paste your cooking steps in the iPhone app.").font(.footnote) }
            }
            SyncFootnote(store: store)
        }
        .navigationTitle("Cooking")
    }
}

struct CookingStepsView: View {
    @ObservedObject var store: WatchStore
    var sectionID: String
    private var current: CookingSection? { store.state?.recipe.sections.first { $0.id == sectionID } }
    var body: some View {
        List {
            if let current {
                ProgressHeader(title: "This section", progress: current.progress, tint: .green)
                Text(current.title).font(.headline)
                ForEach(current.steps) { step in
                    Button { store.setChecked(target: .cooking, id: step.id, done: !step.done) } label: {
                        CheckRow(text: step.text, done: step.done, tint: .green)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(step.text)
                    .accessibilityValue(step.done ? "Complete" : "Not complete")
                    .accessibilityHint(step.done ? "Mark as not complete" : "Mark as complete")
                }
            } else { Text("This section changed on iPhone. Go back to your recipe.").font(.footnote) }
            SyncFootnote(store: store)
        }
        .navigationTitle("Cooking steps")
    }
}

struct CheckRow: View {
    var text: String
    var done: Bool
    var tint: Color
    var body: some View {
        HStack(alignment: .top, spacing: 9) {
            Image(systemName: done ? "checkmark.circle.fill" : "circle")
                .font(.title3).foregroundStyle(done ? tint : .gray)
                .accessibilityHidden(true)
            Text(text).font(.body).foregroundStyle(done ? .secondary : .primary)
                .strikethrough(done).fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
        .padding(.vertical, 7)
        .contentShape(Rectangle())
    }
}

struct SyncFootnote: View {
    @ObservedObject var store: WatchStore
    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            if let notice = store.notice { Text(notice).foregroundStyle(.orange) }
            Text(store.connectionText).foregroundStyle(.secondary)
            if store.pendingCount == 0 { Text("Edit lists on iPhone.").foregroundStyle(.secondary) }
        }
        .font(.caption2)
    }
}
