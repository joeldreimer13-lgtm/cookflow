import Foundation
import Combine
import WatchConnectivity

@MainActor
final class WatchStore: NSObject, ObservableObject {
    static let shared = WatchStore()
    @Published private(set) var state: CookFlowState?
    @Published private(set) var pendingCount = 0
    @Published private(set) var connectionText = "Open CookFlow on iPhone to connect."
    @Published private(set) var notice: String?
    let isPreview: Bool
    private var replica: WatchReplica
    private let session: WCSession?
    private var inFlight: Set<String> = []

    private override init() {
        isPreview = ProcessInfo.processInfo.arguments.contains("--preview")
        if isPreview {
            replica = WatchReplica(canonical: PhoneRecord(state: DeviceFiles.seed()).snapshot)
        } else if let saved = DeviceFiles.read(WatchReplica.self, name: "watch-state.json"),
                  saved.canonical == nil || (try? saved.canonical?.state.validate()) != nil {
            replica = saved
        } else { replica = WatchReplica() }
        state = replica.displayedState
        pendingCount = replica.pending.count
        session = !isPreview && WCSession.isSupported() ? WCSession.default : nil
        super.init()
        if isPreview { connectionText = "Preview data"; return }
        do { try DeviceFiles.write(replica, name: "watch-state.json") }
        catch { notice = "CookFlow could not save its data on this Watch." }
        session?.delegate = self
        session?.activate()
        updateStatus()
    }

    func setChecked(target: CheckTarget, id: String, done: Bool) {
        var next = replica
        guard next.enqueue(target: target, itemID: id, done: done) != nil else { return }
        do {
            if !isPreview { try DeviceFiles.write(next, name: "watch-state.json") }
            replica = next
            state = next.displayedState
            pendingCount = next.pending.count
            notice = nil
            updateStatus()
            flushPending()
        } catch { notice = "This change could not be saved. Please try again." }
    }

    func refresh() {
        guard !isPreview, let session else { return }
        if session.activationState != .activated { session.activate(); return }
        if let data = session.receivedApplicationContext[CookFlowWire.snapshotKey] as? Data { receiveSnapshot(data) }
        flushPending()
        if session.isReachable {
            session.sendMessage([CookFlowWire.requestKey: true], replyHandler: { [weak self] message in
                Task { @MainActor in self?.receive(message) }
            }, errorHandler: { [weak self] _ in Task { @MainActor in self?.updateStatus() } })
        } else {
            try? session.updateApplicationContext([CookFlowWire.requestKey: true, "requestedAt": Date().timeIntervalSince1970])
        }
        updateStatus()
    }

    private func updateStatus() {
        if isPreview { connectionText = "Preview data"; return }
        if pendingCount > 0 {
            connectionText = "\(pendingCount) \(pendingCount == 1 ? "change" : "changes") saved on Watch · waiting to sync"
        } else if state != nil {
            connectionText = session?.isReachable == true ? "Connected · saved on Watch" : "Saved on Watch · iPhone currently unavailable"
        } else {
            connectionText = "Open CookFlow on your paired iPhone to receive your lists."
        }
    }

    private func receive(_ message: [String: Any]) {
        if let data = message[CookFlowWire.snapshotKey] as? Data { receiveSnapshot(data) }
    }

    private func receiveSnapshot(_ data: Data) {
        do {
            let snapshot = try CookFlowWire.snapshot(data)
            var next = replica
            let message = next.receive(snapshot)
            try DeviceFiles.write(next, name: "watch-state.json")
            replica = next
            state = next.displayedState
            pendingCount = next.pending.count
            if let message { notice = message }
            updateStatus()
            flushPending()
        } catch { notice = "Could not read the latest lists. Open CookFlow on iPhone and tap Sync again." }
    }

    private func flushPending() {
        guard !isPreview, let session, session.activationState == .activated else { return }
        let queued = Set(session.outstandingUserInfoTransfers.compactMap { transfer -> String? in
            guard let data = transfer.userInfo[CookFlowWire.mutationKey] as? Data else { return nil }
            return (try? JSONDecoder().decode(CheckMutation.self, from: data))?.id
        })
        for command in replica.pending {
            guard let data = try? CookFlowWire.encode(command) else { continue }
            if !queued.contains(command.id) { session.transferUserInfo([CookFlowWire.mutationKey: data]) }
            if session.isReachable && !inFlight.contains(command.id) {
                inFlight.insert(command.id)
                session.sendMessage([CookFlowWire.mutationKey: data], replyHandler: { [weak self] response in
                    Task { @MainActor in
                        self?.inFlight.remove(command.id)
                        self?.receive(response)
                    }
                }, errorHandler: { [weak self] _ in
                    Task { @MainActor in self?.inFlight.remove(command.id); self?.updateStatus() }
                })
            }
        }
    }
}

extension WatchStore: WCSessionDelegate {
    nonisolated func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        Task { @MainActor in self.refresh() }
    }
    nonisolated func sessionReachabilityDidChange(_ session: WCSession) {
        Task { @MainActor in self.refresh() }
    }
    nonisolated func session(_ session: WCSession, didReceiveApplicationContext applicationContext: [String: Any]) {
        Task { @MainActor in self.receive(applicationContext) }
    }
    nonisolated func session(_ session: WCSession, didReceiveMessage message: [String: Any]) {
        Task { @MainActor in self.receive(message) }
    }
    nonisolated func session(_ session: WCSession, didReceiveMessage message: [String: Any], replyHandler: @escaping ([String: Any]) -> Void) {
        replyHandler(["received": true])
        Task { @MainActor in self.receive(message) }
    }
    nonisolated func session(_ session: WCSession, didReceive file: WCSessionFile) {
        guard file.metadata?["kind"] as? String == "cookflow-snapshot" else { return }
        // Apple removes the temporary file after this delegate returns, so read it now.
        guard let data = try? Data(contentsOf: file.fileURL) else { return }
        Task { @MainActor in self.receiveSnapshot(data) }
    }
    nonisolated func session(_ session: WCSession, didFinish userInfoTransfer: WCSessionUserInfoTransfer, error: Error?) {
        if error != nil { Task { @MainActor in self.updateStatus() } }
    }
}
