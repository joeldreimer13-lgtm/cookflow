import Foundation
import Combine
import WatchConnectivity

@MainActor
final class PhoneStore: NSObject, ObservableObject {
    static let shared = PhoneStore()
    @Published private(set) var snapshot: SyncSnapshot
    @Published private(set) var connectionText = "Connecting to Apple Watch…"
    @Published var lastError: String?
    private var record: PhoneRecord
    private let session: WCSession?

    private override init() {
        let saved = DeviceFiles.read(PhoneRecord.self, name: "phone-state.json")
        let loaded: PhoneRecord
        if let saved, (try? saved.snapshot.state.validate()) != nil { loaded = saved }
        else { loaded = PhoneRecord(state: DeviceFiles.seed()) }
        record = loaded
        snapshot = loaded.snapshot
        session = WCSession.isSupported() ? WCSession.default : nil
        super.init()
        do { try DeviceFiles.write(record, name: "phone-state.json") }
        catch { lastError = "CookFlow could not save its data on this iPhone." }
        session?.delegate = self
        session?.activate()
        updateConnection()
    }

    func receiveWebState(_ state: CookFlowState, basedOn baseline: CookFlowState) {
        do {
            var next = record
            guard try next.acceptWebState(state, basedOn: baseline) else { return }
            try commit(next)
        } catch { lastError = "The iPhone list could not be saved for Watch syncing. \(error.localizedDescription)" }
    }

    func importState(_ state: CookFlowState) throws {
        var next = record
        try next.replace(with: state)
        try commit(next)
    }

    private func commit(_ next: PhoneRecord) throws {
        // Never acknowledge Watch changes until their result has been saved atomically.
        try DeviceFiles.write(next, name: "phone-state.json")
        record = next
        snapshot = next.snapshot
        lastError = nil
        sendSnapshot()
    }

    func refreshConnection() {
        if session?.activationState != .activated { session?.activate() }
        updateConnection()
        sendSnapshot()
    }

    private func updateConnection() {
        guard let session else { connectionText = "Apple Watch is not supported on this device."; return }
        guard session.activationState == .activated else { connectionText = "Connecting to Apple Watch…"; return }
        if !session.isPaired { connectionText = "Pair an Apple Watch with this iPhone." }
        else if !session.isWatchAppInstalled { connectionText = "Install CookFlow from the Watch app on your iPhone." }
        else if session.isReachable { connectionText = "Watch connected · changes save automatically" }
        else { connectionText = "Saved on iPhone · Watch syncs when available" }
    }

    private func sendSnapshot() {
        guard let session, session.activationState == .activated, session.isPaired, session.isWatchAppInstalled else { return }
        updateConnection()
        do {
            let data = try CookFlowWire.encode(record.snapshot)
            if data.count <= CookFlowWire.inlineLimit {
                try session.updateApplicationContext([CookFlowWire.snapshotKey: data])
                if session.isReachable {
                    session.sendMessage([CookFlowWire.snapshotKey: data], replyHandler: nil) { _ in }
                }
            } else {
                // Background file transfer avoids Watch Connectivity's dictionary size limit.
                let alreadyQueued = session.outstandingFileTransfers.contains {
                    ($0.file.metadata?["documentID"] as? String) == record.snapshot.documentID &&
                    ($0.file.metadata?["revision"] as? NSNumber)?.int64Value == record.snapshot.revision &&
                    ($0.file.metadata?["modifiedAt"] as? NSNumber)?.doubleValue == record.snapshot.modifiedAt
                }
                if !alreadyQueued {
                    let root = FileManager.default.temporaryDirectory.appendingPathComponent("CookFlowTransfers", isDirectory: true)
                    try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
                    let path = root.appendingPathComponent(UUID().uuidString + ".json")
                    try data.write(to: path, options: .atomic)
                    session.transferFile(path, metadata: ["kind": "cookflow-snapshot", "documentID": record.snapshot.documentID,
                        "revision": NSNumber(value: record.snapshot.revision), "modifiedAt": NSNumber(value: record.snapshot.modifiedAt)])
                }
            }
        } catch { lastError = "Your lists are saved on iPhone. Watch syncing will retry when available." }
    }

    private func receive(_ message: [String: Any], reply: (([String: Any]) -> Void)? = nil) {
        if let data = message[CookFlowWire.mutationKey] as? Data {
            do {
                let command = try JSONDecoder().decode(CheckMutation.self, from: data)
                var next = record
                next.apply(command)
                try commit(next)
            } catch { lastError = "A Watch change could not be saved and will retry." }
        } else if message[CookFlowWire.requestKey] != nil { sendSnapshot() }
        if let reply {
            if let data = try? CookFlowWire.encode(record.snapshot), data.count <= CookFlowWire.inlineLimit {
                reply([CookFlowWire.snapshotKey: data])
            } else {
                sendSnapshot()
                reply(["queuedFile": true])
            }
        }
    }
}

extension PhoneStore: WCSessionDelegate {
    nonisolated func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        Task { @MainActor in self.updateConnection(); self.sendSnapshot() }
    }
    nonisolated func sessionDidBecomeInactive(_ session: WCSession) {}
    nonisolated func sessionDidDeactivate(_ session: WCSession) { session.activate() }
    nonisolated func sessionWatchStateDidChange(_ session: WCSession) {
        Task { @MainActor in self.updateConnection(); self.sendSnapshot() }
    }
    nonisolated func sessionReachabilityDidChange(_ session: WCSession) {
        Task { @MainActor in self.updateConnection(); self.sendSnapshot() }
    }
    nonisolated func session(_ session: WCSession, didReceiveMessage message: [String: Any], replyHandler: @escaping ([String: Any]) -> Void) {
        Task { @MainActor in self.receive(message, reply: replyHandler) }
    }
    nonisolated func session(_ session: WCSession, didReceiveMessage message: [String: Any]) {
        Task { @MainActor in self.receive(message) }
    }
    nonisolated func session(_ session: WCSession, didReceiveUserInfo userInfo: [String: Any]) {
        Task { @MainActor in self.receive(userInfo) }
    }
    nonisolated func session(_ session: WCSession, didReceiveApplicationContext applicationContext: [String: Any]) {
        Task { @MainActor in self.receive(applicationContext) }
    }
    nonisolated func session(_ session: WCSession, didFinish fileTransfer: WCSessionFileTransfer, error: Error?) {
        let path = fileTransfer.file.fileURL
        if path.deletingLastPathComponent().lastPathComponent == "CookFlowTransfers" { try? FileManager.default.removeItem(at: path) }
        if error != nil { Task { @MainActor in self.lastError = "Your lists are saved. Open both CookFlow apps to retry Watch syncing." } }
    }
}
