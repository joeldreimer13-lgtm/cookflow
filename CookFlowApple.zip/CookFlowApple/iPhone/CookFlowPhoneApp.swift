import SwiftUI
import UniformTypeIdentifiers

extension UTType {
    static let cookFlowBackup = UTType(exportedAs: "com.joelreimer.cookflow.backup", conformingTo: .json)
}

struct BackupDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.cookFlowBackup, .json] }
    var state: CookFlowState
    init(state: CookFlowState) { self.state = state }
    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents else { throw DocumentError.invalid("Choose a CookFlow backup file.") }
        state = try CookFlowBackup.read(data)
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: try CookFlowWire.encode(CookFlowBackup(state: state)))
    }
}

@MainActor
final class PhoneAppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        _ = PhoneStore.shared
        return true
    }
}

@main
@MainActor
struct CookFlowPhoneApp: App {
    @UIApplicationDelegateAdaptor(PhoneAppDelegate.self) private var delegate
    @StateObject private var store = PhoneStore.shared
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup { PhoneRootView(store: store) }
            .onChange(of: scenePhase) { _, phase in if phase == .active { store.refreshConnection() } }
    }
}

@MainActor
struct PhoneRootView: View {
    @ObservedObject var store: PhoneStore
    @State private var showImporter = false
    @State private var showExporter = false
    @State private var pendingImport: CookFlowState?
    @State private var confirmImport = false
    @State private var errorMessage: String?
    @State private var showHelp = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                CookFlowWebView(store: store)
                HStack(spacing: 7) {
                    Image(systemName: "applewatch")
                    Text(store.connectionText).font(.caption)
                    Spacer(minLength: 0)
                    Button { store.refreshConnection() } label: { Image(systemName: "arrow.clockwise") }
                        .accessibilityLabel("Retry Watch sync")
                }
                .foregroundStyle(.secondary).padding(.horizontal, 14).padding(.vertical, 9)
                .background(.bar)
            }
            .navigationTitle("CookFlow")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { showHelp = true } label: { Image(systemName: "applewatch") }
                        .accessibilityLabel("Watch setup")
                }
                ToolbarItemGroup(placement: .topBarTrailing) {
                    PasteButton(payloadType: String.self) { values in
                        guard let text = values.first else { return }
                        do { pendingImport = try CookFlowBackup.read(Data(text.utf8)); confirmImport = true }
                        catch { errorMessage = "The clipboard does not contain a valid CookFlow backup." }
                    }
                    .labelStyle(.iconOnly)
                    .accessibilityLabel("Paste saved CookFlow lists")
                    Button { showImporter = true } label: { Image(systemName: "square.and.arrow.down") }
                        .accessibilityLabel("Import saved CookFlow lists")
                    Button { showExporter = true } label: { Image(systemName: "square.and.arrow.up") }
                        .accessibilityLabel("Save a backup of your lists")
                }
            }
        }
        .tint(Color(red: 44/255, green: 113/255, blue: 88/255))
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.cookFlowBackup, .json]) { result in
            do { stageImport(try result.get()) } catch { errorMessage = error.localizedDescription }
        }
        .fileExporter(isPresented: $showExporter, document: BackupDocument(state: store.snapshot.state),
            contentType: .cookFlowBackup, defaultFilename: "CookFlow-backup") { result in
            if case .failure(let error) = result { errorMessage = error.localizedDescription }
        }
        .onOpenURL { if $0.isFileURL { stageImport($0) } }
        .alert("Import your saved lists?", isPresented: $confirmImport) {
            Button("Cancel", role: .cancel) { pendingImport = nil }
            Button("Import lists") {
                guard let state = pendingImport else { return }
                do { try store.importState(state); pendingImport = nil }
                catch { errorMessage = error.localizedDescription }
            }
        } message: { Text("This replaces the lists in this companion app and on your Watch. Your Safari copy stays separate. Save a backup first if needed.") }
        .alert("CookFlow", isPresented: Binding(get: { errorMessage != nil || store.lastError != nil }, set: { if !$0 { errorMessage = nil; store.lastError = nil } })) {
            Button("OK", role: .cancel) { errorMessage = nil; store.lastError = nil }
        } message: { Text(errorMessage ?? store.lastError ?? "") }
        .sheet(isPresented: $showHelp) { WatchSetupView() }
    }

    private func stageImport(_ url: URL) {
        do { pendingImport = try DeviceFiles.readBackup(at: url); confirmImport = true }
        catch { errorMessage = "Could not open this backup. \(error.localizedDescription)" }
    }
}

struct WatchSetupView: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                Section("Bring your existing lists") {
                    Text("In your Safari or Home Screen CookFlow, open ‘Move or back up your lists’ and tap ‘Copy for companion’. Return here and tap Paste in the top toolbar.")
                    Text("You can also tap ‘Save lists’, save the file in Files, and use the import icon here to choose it.")
                }
                Section("Connect your Watch") {
                    Text("Install CookFlow on your paired Apple Watch, then open CookFlow on both devices once.")
                    Text("Use this iPhone companion app to edit your lists. Check items off on either device.")
                }
                Section("Away from your phone") {
                    Text("Your Watch keeps its last received lists and saves checkbox changes offline. Changes are sent when Apple’s connection becomes available; background delivery may take time.")
                    Text("If you change the same checkbox on iPhone while Watch is offline, the newer iPhone change is kept. Deleted items are never brought back by an old Watch change.")
                }
                Section("Safari stays separate") {
                    Text("The original website and Home Screen shortcut cannot read this app’s storage. Use the companion app for automatic Watch sync. Export a backup here to move changes back to Safari manually.")
                }
            }
            .navigationTitle("Watch setup")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
}
