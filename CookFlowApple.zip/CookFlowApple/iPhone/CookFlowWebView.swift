import SwiftUI
import WebKit

@MainActor
struct CookFlowWebView: UIViewRepresentable {
    @ObservedObject var store: PhoneStore

    func makeCoordinator() -> Coordinator { Coordinator(store: store) }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        let controller = configuration.userContentController
        controller.add(context.coordinator, name: "cookflow")
        let initial = (try? CookFlowWire.encode(store.snapshot.state)) ?? Data("{}".utf8)
        let initialJSON = String(decoding: initial, as: UTF8.self)
        let documentJSON = String(decoding: (try? CookFlowWire.encode(store.snapshot.documentID)) ?? Data("\"\"".utf8), as: UTF8.self)
        let bootstrap = """
        window.CookFlowNative = window.CookFlowNative || {};
        window.CookFlowNative.isNative = true;
        try {
          const initial = \(initialJSON);
          window.CookFlowNative.documentID = \(documentJSON);
          window.CookFlowNative.bridgeBaseline = initial;
          localStorage.setItem('cookflow-recipe-v1', JSON.stringify(initial.recipe));
          localStorage.setItem('cookflow-shopping-v1', JSON.stringify(initial.shopping));
        } catch (_) {}
        """
        controller.addUserScript(WKUserScript(source: bootstrap, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        let bridge = """
        document.documentElement.classList.add('native-app');
        window.addEventListener('cookflow-change', () => {
          try {
            const api = window.CookFlowNative, state = api.getState();
            const baseline = api.bridgeBaseline || state;
            window.webkit.messageHandlers.cookflow.postMessage({type:'state', state, baseState:baseline, documentID:api.documentID});
            api.bridgeBaseline = state;
          } catch (_) {}
        });
        """
        controller.addUserScript(WKUserScript(source: bridge, injectionTime: .atDocumentEnd, forMainFrameOnly: true))
        let view = WKWebView(frame: .zero, configuration: configuration)
        view.isOpaque = false
        view.backgroundColor = UIColor(red: 247/255, green: 246/255, blue: 240/255, alpha: 1)
        view.navigationDelegate = context.coordinator
        context.coordinator.webView = view
        if let path = Bundle.main.url(forResource: "index", withExtension: "html") {
            view.loadFileURL(path, allowingReadAccessTo: path.deletingLastPathComponent())
        }
        return view
    }

    func updateUIView(_ view: WKWebView, context: Context) { context.coordinator.apply(store.snapshot) }

    static func dismantleUIView(_ uiView: WKWebView, coordinator: Coordinator) {
        uiView.configuration.userContentController.removeScriptMessageHandler(forName: "cookflow")
        uiView.navigationDelegate = nil
    }

    @MainActor
    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate {
        let store: PhoneStore
        weak var webView: WKWebView?
        private var ready = false
        private var lastState: CookFlowState?
        private var lastDocumentID: String?

        init(store: PhoneStore) { self.store = store }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.frameInfo.isMainFrame, message.name == "cookflow",
                  let body = message.body as? [String: Any], body["type"] as? String == "state",
                  let object = body["state"], let baseObject = body["baseState"],
                  JSONSerialization.isValidJSONObject(object), JSONSerialization.isValidJSONObject(baseObject),
                  let data = try? JSONSerialization.data(withJSONObject: object),
                  let baseData = try? JSONSerialization.data(withJSONObject: baseObject),
                  let state = try? JSONDecoder().decode(CookFlowState.self, from: data),
                  let baseline = try? JSONDecoder().decode(CookFlowState.self, from: baseData),
                  (try? state.validate()) != nil else { return }
            guard body["documentID"] as? String == store.snapshot.documentID else {
                lastState = nil
                apply(store.snapshot)
                return
            }
            lastState = state
            store.receiveWebState(state, basedOn: baseline)
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            ready = true
            lastState = nil
            apply(store.snapshot)
        }

        func apply(_ snapshot: SyncSnapshot) {
            let state = snapshot.state
            let replace = lastDocumentID != nil && snapshot.documentID != lastDocumentID
            guard ready, state != lastState || replace, let webView,
                  let data = try? CookFlowWire.encode(state),
                  let object = try? JSONSerialization.jsonObject(with: data) else { return }
            lastState = state
            lastDocumentID = snapshot.documentID
            Task { @MainActor [weak self, weak webView] in
                guard let webView else { return }
                do {
                    _ = try await webView.callAsyncJavaScript(
                        "window.CookFlowNative.documentID=documentID; return window.CookFlowNative.applyState(state, replace)",
                        arguments: ["state": object, "replace": replace, "documentID": snapshot.documentID],
                        in: nil, contentWorld: .page)
                } catch {
                    self?.lastState = nil
                    self?.store.lastError = "Could not refresh the checklist. Reopen CookFlow to retry."
                }
            }
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
            if url.isFileURL || url.scheme == "about" { decisionHandler(.allow); return }
            if navigationAction.navigationType == .linkActivated, ["https", "http"].contains(url.scheme ?? "") {
                UIApplication.shared.open(url)
            }
            decisionHandler(.cancel)
        }
    }
}
